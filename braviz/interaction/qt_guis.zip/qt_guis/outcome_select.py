# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\da.angulo39\programas\braviz\braviz\interaction\qt_guis\outcome_select.ui'
#
# Created: Tue Nov 11 14:37:50 2014
#      by: PyQt4 UI code generator 4.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_SelectOutcomeDialog(object):
    def setupUi(self, SelectOutcomeDialog):
        SelectOutcomeDialog.setObjectName(_fromUtf8("SelectOutcomeDialog"))
        SelectOutcomeDialog.setWindowModality(QtCore.Qt.ApplicationModal)
        SelectOutcomeDialog.resize(967, 452)
        SelectOutcomeDialog.setLocale(QtCore.QLocale(QtCore.QLocale.English, QtCore.QLocale.UnitedStates))
        SelectOutcomeDialog.setSizeGripEnabled(True)
        SelectOutcomeDialog.setModal(True)
        self.horizontalLayout = QtGui.QHBoxLayout(SelectOutcomeDialog)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.frame_3 = QtGui.QFrame(SelectOutcomeDialog)
        self.frame_3.setFrameShape(QtGui.QFrame.NoFrame)
        self.frame_3.setFrameShadow(QtGui.QFrame.Raised)
        self.frame_3.setObjectName(_fromUtf8("frame_3"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.frame_3)
        self.verticalLayout_2.setMargin(0)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.search_box = QtGui.QLineEdit(self.frame_3)
        self.search_box.setObjectName(_fromUtf8("search_box"))
        self.verticalLayout_2.addWidget(self.search_box)
        self.tableView = QtGui.QTableView(self.frame_3)
        self.tableView.setMinimumSize(QtCore.QSize(100, 0))
        self.tableView.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tableView.setObjectName(_fromUtf8("tableView"))
        self.tableView.horizontalHeader().setStretchLastSection(True)
        self.verticalLayout_2.addWidget(self.tableView)
        self.horizontalLayout.addWidget(self.frame_3)
        self.frame = QtGui.QFrame(SelectOutcomeDialog)
        self.frame.setMinimumSize(QtCore.QSize(340, 0))
        self.frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.frame.setFrameShadow(QtGui.QFrame.Raised)
        self.frame.setObjectName(_fromUtf8("frame"))
        self.verticalLayout = QtGui.QVBoxLayout(self.frame)
        self.verticalLayout.setContentsMargins(0, -1, 0, 0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.var_name = QtGui.QLabel(self.frame)
        self.var_name.setMaximumSize(QtCore.QSize(16777215, 23))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.var_name.setFont(font)
        self.var_name.setAlignment(QtCore.Qt.AlignHCenter|QtCore.Qt.AlignTop)
        self.var_name.setObjectName(_fromUtf8("var_name"))
        self.verticalLayout.addWidget(self.var_name)
        self.frame_2 = QtGui.QFrame(self.frame)
        self.frame_2.setFrameShape(QtGui.QFrame.NoFrame)
        self.frame_2.setFrameShadow(QtGui.QFrame.Raised)
        self.frame_2.setObjectName(_fromUtf8("frame_2"))
        self.formLayout = QtGui.QFormLayout(self.frame_2)
        self.formLayout.setObjectName(_fromUtf8("formLayout"))
        self.label_2 = QtGui.QLabel(self.frame_2)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label_2)
        self.var_type_combo = QtGui.QComboBox(self.frame_2)
        self.var_type_combo.setEnabled(False)
        self.var_type_combo.setObjectName(_fromUtf8("var_type_combo"))
        self.var_type_combo.addItem(_fromUtf8(""))
        self.var_type_combo.addItem(_fromUtf8(""))
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.var_type_combo)
        self.label = QtGui.QLabel(self.frame_2)
        self.label.setObjectName(_fromUtf8("label"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.LabelRole, self.label)
        self.var_description = QtGui.QPlainTextEdit(self.frame_2)
        self.var_description.setEnabled(False)
        self.var_description.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.var_description.setObjectName(_fromUtf8("var_description"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.FieldRole, self.var_description)
        self.verticalLayout.addWidget(self.frame_2)
        self.details_frame = QtGui.QFrame(self.frame)
        self.details_frame.setMinimumSize(QtCore.QSize(0, 125))
        self.details_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.details_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.details_frame.setObjectName(_fromUtf8("details_frame"))
        self.verticalLayoutWidget = QtGui.QWidget(self.details_frame)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 40, 160, 80))
        self.verticalLayoutWidget.setObjectName(_fromUtf8("verticalLayoutWidget"))
        self.details_layout = QtGui.QVBoxLayout(self.verticalLayoutWidget)
        self.details_layout.setMargin(0)
        self.details_layout.setObjectName(_fromUtf8("details_layout"))
        self.verticalLayout.addWidget(self.details_frame)
        self.frame_4 = QtGui.QFrame(self.frame)
        self.frame_4.setFrameShape(QtGui.QFrame.NoFrame)
        self.frame_4.setFrameShadow(QtGui.QFrame.Raised)
        self.frame_4.setObjectName(_fromUtf8("frame_4"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.frame_4)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.save_button = QtGui.QPushButton(self.frame_4)
        self.save_button.setEnabled(False)
        self.save_button.setObjectName(_fromUtf8("save_button"))
        self.horizontalLayout_2.addWidget(self.save_button)
        self.select_button = QtGui.QPushButton(self.frame_4)
        self.select_button.setEnabled(False)
        self.select_button.setObjectName(_fromUtf8("select_button"))
        self.horizontalLayout_2.addWidget(self.select_button)
        self.verticalLayout.addWidget(self.frame_4)
        self.verticalLayout.setStretch(1, 1)
        self.verticalLayout.setStretch(2, 2)
        self.horizontalLayout.addWidget(self.frame)
        self.plot_frame = QtGui.QFrame(SelectOutcomeDialog)
        self.plot_frame.setMinimumSize(QtCore.QSize(300, 0))
        self.plot_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.plot_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.plot_frame.setObjectName(_fromUtf8("plot_frame"))
        self.horizontalLayout.addWidget(self.plot_frame)
        self.label_2.setBuddy(self.var_type_combo)
        self.label.setBuddy(self.var_description)

        self.retranslateUi(SelectOutcomeDialog)
        QtCore.QMetaObject.connectSlotsByName(SelectOutcomeDialog)

    def retranslateUi(self, SelectOutcomeDialog):
        SelectOutcomeDialog.setWindowTitle(_translate("SelectOutcomeDialog", "Select Outcome Variable", None))
        self.search_box.setPlaceholderText(_translate("SelectOutcomeDialog", "Search", None))
        self.var_name.setText(_translate("SelectOutcomeDialog", "Select Outcome Variable", None))
        self.label_2.setText(_translate("SelectOutcomeDialog", "Type :", None))
        self.var_type_combo.setItemText(0, _translate("SelectOutcomeDialog", "Real", None))
        self.var_type_combo.setItemText(1, _translate("SelectOutcomeDialog", "Nominal", None))
        self.label.setText(_translate("SelectOutcomeDialog", "Description :", None))
        self.save_button.setText(_translate("SelectOutcomeDialog", "Save", None))
        self.select_button.setText(_translate("SelectOutcomeDialog", "Save and Select", None))

