# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\da.angulo39\programas\braviz\braviz\interaction\qt_guis\import_from_excel.ui'
#
# Created: Tue Nov 11 14:37:50 2014
#      by: PyQt4 UI code generator 4.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_import_from_excel(object):
    def setupUi(self, import_from_excel):
        import_from_excel.setObjectName(_fromUtf8("import_from_excel"))
        import_from_excel.resize(926, 705)
        self.gridLayout = QtGui.QGridLayout(import_from_excel)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.select_file_button = QtGui.QPushButton(import_from_excel)
        self.select_file_button.setObjectName(_fromUtf8("select_file_button"))
        self.gridLayout.addWidget(self.select_file_button, 0, 0, 1, 1)
        self.tableView = QtGui.QTableView(import_from_excel)
        self.tableView.setAlternatingRowColors(True)
        self.tableView.setObjectName(_fromUtf8("tableView"))
        self.gridLayout.addWidget(self.tableView, 3, 0, 1, 4)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 0, 3, 1, 1)
        self.buttonBox = QtGui.QDialogButtonBox(import_from_excel)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Close|QtGui.QDialogButtonBox.Save)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.gridLayout.addWidget(self.buttonBox, 4, 0, 1, 4)
        self.file_name_label = QtGui.QLineEdit(import_from_excel)
        self.file_name_label.setReadOnly(True)
        self.file_name_label.setObjectName(_fromUtf8("file_name_label"))
        self.gridLayout.addWidget(self.file_name_label, 0, 2, 1, 1)
        self.label = QtGui.QLabel(import_from_excel)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 2, 0, 1, 1)
        self.omitExistent = QtGui.QCheckBox(import_from_excel)
        self.omitExistent.setObjectName(_fromUtf8("omitExistent"))
        self.gridLayout.addWidget(self.omitExistent, 1, 0, 1, 1)

        self.retranslateUi(import_from_excel)
        QtCore.QMetaObject.connectSlotsByName(import_from_excel)

    def retranslateUi(self, import_from_excel):
        import_from_excel.setWindowTitle(_translate("import_from_excel", "Dialog", None))
        self.select_file_button.setText(_translate("import_from_excel", "Select File", None))
        self.label.setText(_translate("import_from_excel", "Preview:", None))
        self.omitExistent.setToolTip(_translate("import_from_excel", "Omit variables whose name appears already in the database", None))
        self.omitExistent.setText(_translate("import_from_excel", "Omit existent", None))

