# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\da.angulo39\programas\braviz\braviz\interaction\qt_guis\new_variable_dialog.ui'
#
# Created: Tue Nov 11 14:37:50 2014
#      by: PyQt4 UI code generator 4.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_NewVariableDialog(object):
    def setupUi(self, NewVariableDialog):
        NewVariableDialog.setObjectName(_fromUtf8("NewVariableDialog"))
        NewVariableDialog.setWindowModality(QtCore.Qt.ApplicationModal)
        NewVariableDialog.resize(887, 504)
        NewVariableDialog.setLocale(QtCore.QLocale(QtCore.QLocale.English, QtCore.QLocale.UnitedStates))
        NewVariableDialog.setSizeGripEnabled(True)
        NewVariableDialog.setModal(True)
        self.horizontalLayout = QtGui.QHBoxLayout(NewVariableDialog)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.frame = QtGui.QFrame(NewVariableDialog)
        self.frame.setMinimumSize(QtCore.QSize(340, 0))
        self.frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.frame.setFrameShadow(QtGui.QFrame.Raised)
        self.frame.setObjectName(_fromUtf8("frame"))
        self.verticalLayout = QtGui.QVBoxLayout(self.frame)
        self.verticalLayout.setContentsMargins(0, -1, 0, 0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.frame_2 = QtGui.QFrame(self.frame)
        self.frame_2.setFrameShape(QtGui.QFrame.NoFrame)
        self.frame_2.setFrameShadow(QtGui.QFrame.Raised)
        self.frame_2.setObjectName(_fromUtf8("frame_2"))
        self.formLayout = QtGui.QFormLayout(self.frame_2)
        self.formLayout.setObjectName(_fromUtf8("formLayout"))
        self.label_2 = QtGui.QLabel(self.frame_2)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.formLayout.setWidget(2, QtGui.QFormLayout.LabelRole, self.label_2)
        self.var_type_combo = QtGui.QComboBox(self.frame_2)
        self.var_type_combo.setEnabled(True)
        self.var_type_combo.setObjectName(_fromUtf8("var_type_combo"))
        self.var_type_combo.addItem(_fromUtf8(""))
        self.var_type_combo.addItem(_fromUtf8(""))
        self.formLayout.setWidget(2, QtGui.QFormLayout.FieldRole, self.var_type_combo)
        self.var_name = QtGui.QLabel(self.frame_2)
        self.var_name.setMaximumSize(QtCore.QSize(16777215, 23))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.var_name.setFont(font)
        self.var_name.setAlignment(QtCore.Qt.AlignHCenter|QtCore.Qt.AlignTop)
        self.var_name.setObjectName(_fromUtf8("var_name"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.var_name)
        self.var_name_input = QtGui.QLineEdit(self.frame_2)
        self.var_name_input.setObjectName(_fromUtf8("var_name_input"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.var_name_input)
        self.label = QtGui.QLabel(self.frame_2)
        self.label.setObjectName(_fromUtf8("label"))
        self.formLayout.setWidget(3, QtGui.QFormLayout.LabelRole, self.label)
        self.var_description = QtGui.QPlainTextEdit(self.frame_2)
        self.var_description.setObjectName(_fromUtf8("var_description"))
        self.formLayout.setWidget(3, QtGui.QFormLayout.FieldRole, self.var_description)
        self.verticalLayout.addWidget(self.frame_2)
        self.details_frame = QtGui.QFrame(self.frame)
        self.details_frame.setObjectName(_fromUtf8("details_frame"))
        self.verticalLayout.addWidget(self.details_frame)
        self.frame_4 = QtGui.QFrame(self.frame)
        self.frame_4.setFrameShape(QtGui.QFrame.NoFrame)
        self.frame_4.setFrameShadow(QtGui.QFrame.Raised)
        self.frame_4.setObjectName(_fromUtf8("frame_4"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.frame_4)
        self.horizontalLayout_2.setMargin(0)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.save_button = QtGui.QPushButton(self.frame_4)
        self.save_button.setEnabled(False)
        self.save_button.setObjectName(_fromUtf8("save_button"))
        self.horizontalLayout_2.addWidget(self.save_button)
        self.select_button = QtGui.QPushButton(self.frame_4)
        self.select_button.setEnabled(True)
        self.select_button.setObjectName(_fromUtf8("select_button"))
        self.horizontalLayout_2.addWidget(self.select_button)
        self.verticalLayout.addWidget(self.frame_4)
        self.verticalLayout.setStretch(0, 1)
        self.verticalLayout.setStretch(1, 3)
        self.horizontalLayout.addWidget(self.frame)
        self.values_frame = QtGui.QFrame(NewVariableDialog)
        self.values_frame.setMinimumSize(QtCore.QSize(300, 0))
        self.values_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.values_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.values_frame.setObjectName(_fromUtf8("values_frame"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.values_frame)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.values_table = QtGui.QTableView(self.values_frame)
        self.values_table.setObjectName(_fromUtf8("values_table"))
        self.values_table.horizontalHeader().setStretchLastSection(True)
        self.values_table.verticalHeader().setVisible(False)
        self.verticalLayout_2.addWidget(self.values_table)
        self.horizontalLayout.addWidget(self.values_frame)
        self.label_2.setBuddy(self.var_type_combo)
        self.var_name.setBuddy(self.var_name_input)
        self.label.setBuddy(self.var_description)

        self.retranslateUi(NewVariableDialog)
        QtCore.QObject.connect(self.select_button, QtCore.SIGNAL(_fromUtf8("clicked()")), NewVariableDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(NewVariableDialog)

    def retranslateUi(self, NewVariableDialog):
        NewVariableDialog.setWindowTitle(_translate("NewVariableDialog", "Create New Variable", None))
        self.label_2.setText(_translate("NewVariableDialog", "Type :", None))
        self.var_type_combo.setItemText(0, _translate("NewVariableDialog", "Real", None))
        self.var_type_combo.setItemText(1, _translate("NewVariableDialog", "Nominal", None))
        self.var_name.setText(_translate("NewVariableDialog", "Variable Name: ", None))
        self.label.setText(_translate("NewVariableDialog", "Description :", None))
        self.save_button.setText(_translate("NewVariableDialog", "Save", None))
        self.select_button.setText(_translate("NewVariableDialog", "Cancel", None))

